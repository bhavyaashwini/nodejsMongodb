const express = require("express");
const router = express.Router();
const mongoose = require("mongoose");
const multer = require('multer');
const imageToBase64 = require('image-to-base64');

const storage = multer.diskStorage({
    destination: function(req, file, cb) {
      cb(null, './uploads/');
    },
    filename: function(req, file, cb) {
      cb(null, file.originalname);
    }
  });

  
//   const upload =multer({dest: 'uploads/'});
const fileFilter = (req, file, cb) => {
    // reject a file
    if (file.mimetype === 'image/jpeg' || file.mimetype === 'image/png') {
      cb(null, true);
    } else {
      cb(null, false);
    }
  };
const upload = multer({
    storage: storage,
    limits: {
      fileSize: 1024 * 1024 * 5
    },
    fileFilter: fileFilter
  });
const Product = require("../models/product");

router.post("/", upload.single('mobile_image'),async (req, res, next)=> {
    // function base64_encode(file){

    // }
    // var ImageFileToSave =  base64_encode(req.body.file);
    // const encoded = req.file.buffer.toString('base64');
    // console.log(encoded);
     imageToBase64(req.file.path) // Path to the image
    
    .then(
        (response) => {
            console.log(response);
            const product = new Product({
                _id: new mongoose.Types.ObjectId(),
                mobile_name: req.body.mobile_name,
                mobile_price: req.body.mobile_price,
                mobile_model: req.body.mobile_model,
                mobile_image: response
              });
              product
              .save()
              
              .then(result => {
                console.log(result);
                res.status(201).json({
                  message: "Created product successfully",
                  createdProduct: {
                    mobile_name: result.mobile_name,
                    mobile_price: result.mobile_price,
                    mobile_model: result.mobile_model,
                    
                      _id: result._id,
                      request: {
                          type: 'GET',
                          url: "http://localhost:3000/products/" + result._id
                      }
                  }
                });
              })
              .catch(err => {
                console.log(err);
                res.status(500).json({
                  error: err
                });
              });
            return response;
            // "cGF0aC90by9maWxlLmpwZw=="
        }
    )
    .catch(
        (error) => {
            console.log(error);
            return error // Logs an error if there was one
        }
    )


//    await imageBase(req.file.path);
      console.log(base64, 'hai');
      console.log(req.file.path,'hello');
  
});

async function imageBase(path){
    imageToBase64(path)
     // Path to the image
    .then(
        (response) => {
            console.log(response);
            return {result:response};
            // "cGF0aC90by9maWxlLmpwZw=="
        }
    )
    .catch(
        (error) => {
            console.log(error); // Logs an error if there was one
        }
    )
}

router.get("/", (req, res, next) => {
    Product.find()
      .select("name price _id productImage")
      .exec()
      .then(docs => {
        const response = {
          count: docs.length,
          products: docs.map(doc => {
            return {
                mobile_name: doc.mobile_name,
                mobile_price: doc.mobile_price,
                mobile_model: doc.mobile_model,
                mobile_image: doc.mobile_image,
              _id: doc._id,
              request: {
                type: "GET",
                url: "http://localhost:3000/products/" + doc._id
              }
            };
          })
        };
        
        res.status(200).json(response);
        
      })
      .catch(err => {
        console.log(err);
        res.status(500).json({
          error: err
        });
      });
  });


module.exports = router;