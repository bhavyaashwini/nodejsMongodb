const mongoose = require('mongoose');

const productSchema = mongoose.Schema({
    _id: mongoose.Schema.Types.ObjectId,
    mobile_name: String,
    mobile_price: Number,
    mobile_model: String,
    mobile_image: { type: String, required: true }
});

module.exports = mongoose.model('Product', productSchema);